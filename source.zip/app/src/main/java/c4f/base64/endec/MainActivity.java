package c4f.base64.endec;
 
import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.graphics.Color;
import android.widget.EditText;
import android.graphics.drawable.GradientDrawable;
import android.widget.Button;
import android.graphics.Typeface;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.Context;
import android.widget.Toast;
import android.text.Html;
import android.view.View;
import android.view.View.OnClickListener;
import android.util.Base64;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import android.view.Window;
import android.annotation.SuppressLint;

public class MainActivity extends Activity { 

    final String appColorA = new String(Base64.decode("IzIyZmY5OQ==",0));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		hideUI();
        setContentView(R.layout.activity_main);
		
		///////DRAWABLES////////
		GradientDrawable edTextDrawable = new GradientDrawable();
		GradientDrawable btnDrawable = new GradientDrawable();
		//////TEXTVIEWS////////
		TextView mT = findViewById(R.id.titleMain);
		TextView sT = findViewById(R.id.subtitle);
		TextView stvtext = findViewById(R.id.sourceTView);
		///////EDITTEXTS///////
		final EditText stvedit = findViewById(R.id.sourceEText);
		///////BUTTONS/////////
		Button btnEncode = findViewById(R.id.convertBtn);
		Button btnDecode = findViewById(R.id.decodeBtn);
		
		
		//DRAWABLE FOR EDITTEXT
		edTextDrawable.setStroke(3, Color.parseColor(appColorA));
		edTextDrawable.setColor(Color.TRANSPARENT);
		float[] radiiii= {22,22,0,0,22,22,0,0};
		edTextDrawable.setCornerRadii(radiiii);
		
		//////////DRAWABLE FOR BUTTONS
		btnDrawable.setStroke(3, Color.parseColor(appColorA));
		btnDrawable.setColor(Color.parseColor(appColorA));
		btnDrawable.setCornerRadii(radiiii);
		
		// MAIN TITLE TEXTVIEW
		mT.setText(new String(Base64.decode("Q2hlYXQ0RnVu",0)));
		mT.setTextColor(Color.parseColor(appColorA));
		
		// SUB TITLE TEXTVIEW
		sT.setText(new String(Base64.decode("QmFzZTY0IFRvb2wgdjEuMA==",0)));
		sT.setTextColor(Color.parseColor(appColorA));
		
		// TEXTVIEW FOR SOURCE INPUT
		stvtext.setText(new String(Base64.decode("RW50ZXIgdGV4dCB0byBFbmNvZGUgLyBEZWNvZGU=",0)));
		stvtext.setTextColor(Color.parseColor(appColorA));
		
		// EDITTEXT FOR SOURCE INPUT
		stvedit.setTextColor(Color.parseColor(appColorA));
		stvedit.setFocusedByDefault(false);
		stvedit.setBackground(edTextDrawable);
		stvedit.setText("");
		
		// BUTTON TO ENCODE TO BASE64
		btnEncode.setBackground(btnDrawable);
		btnEncode.setTextColor(Color.parseColor("#000000"));
		btnEncode.setText( new String( Base64.decode("RW5jb2Rl", 0) ) );
		btnEncode.setTypeface(Typeface.MONOSPACE);
		btnEncode.setOnClickListener(new OnClickListener(){
			public void onClick(View v) {
				final String textTarget = stvedit.getText().toString();
				if(textTarget == ""){  // No Work  :(
				    Toast.makeText(getApplicationContext(), Html.fromHtml(new String(Base64.decode("PGZvbnQgY29sb3I9cmVkPkVycm9yOiAmbmJzcDs8L2ZvbnQ+PGZvbnQgY29sb3I9JyMyMmZmOTknPklucHV0IEVtcHR5IOKaoDwvZm9udD4=",0))), Toast.LENGTH_LONG).show();
				}
				else {
					final String encodedString = new String(Base64.encode(textTarget.getBytes(StandardCharsets.UTF_8), 0));
					copyToClip(encodedString);
					Toast.makeText(getApplicationContext(), Html.fromHtml(new String(Base64.decode("PGZvbnQgY29sb3I9JyMyMmZmOTknPjxiPkVuY29kZWQgVGV4dDwvYj4gQ29waWVkIFRvIENsaXBib2FyZCDimqA8L2ZvbnQ+",0))), Toast.LENGTH_LONG).show();
					stvedit.setText("");
				}
			}
		});
		
		
		btnDecode.setBackground(btnDrawable);
		btnDecode.setTextColor(Color.parseColor("#000000"));
		btnDecode.setText(new String( Base64.decode("RGVjb2Rl", 0) ));
		btnDecode.setTypeface(Typeface.MONOSPACE);
		btnDecode.setOnClickListener(new OnClickListener(){
				public void onClick(View v) {
					final String textTarget = stvedit.getText().toString();
					if(textTarget == ""){  // No Work  :(
						Toast.makeText(getApplicationContext(), Html.fromHtml( new String( Base64.decode( "PGZvbnQgY29sb3I9cmVkPkVycm9yOiAmbmJzcDs8L2ZvbnQ+PGZvbnQgY29sb3I9JyMyMmZmOTknPklucHV0IEVtcHR5IOKaoDwvZm9udD4=" , 0 ) ) ), Toast.LENGTH_LONG).show();
					}
					else {
						final String decodedString = new String(Base64.decode(textTarget.getBytes(StandardCharsets.UTF_8), 0));
						copyToClip(decodedString);
						Toast.makeText(getApplicationContext(), Html.fromHtml("<font color='#22ff99'><b>Decoded Text</b> Copied To Clipboard ⚠</font>"), Toast.LENGTH_LONG).show();
						stvedit.setText("");
					}
				}
			});
    }
	
	public final void copyToClip(String text){
		ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE); 
		ClipData clip = ClipData.newPlainText("", text);
		clipboard.setPrimaryClip(clip);
	}
	
	@SuppressLint("NewApi")
	public final void hideUI()
	{
		final int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
		    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
			| View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
			| View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
			| View.SYSTEM_UI_FLAG_FULLSCREEN
			| View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
			
		getWindow().getDecorView().setSystemUiVisibility(flags);
		
		final View decorView = getWindow().getDecorView();
		decorView
		    .setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener()
			{
				@Override
				public void onSystemUiVisibilityChange(int visibility)
				{
					if((visibility & View.SYSTEM_UI_FLAG_FULLSCREEN)==0)
					{
						decorView.setSystemUiVisibility(flags);
					}
				}
			});
	}
} 
